package archonmovement;

import battlecode.common.*;

public class Lumberjack extends BaseRobot {
	
	public Lumberjack(RobotController rc) {
		super(rc);
		// TODO Auto-generated constructor stub
	}
	public void init() {
		
	}
	
	public void run() throws GameActionException {
		Team ourTeam  = rc.getTeam();
		RobotInfo[] robots = rc.senseNearbyRobots(-1, ourTeam);
		RobotInfo gardener = null;
		for(RobotInfo robot : robots) {
			if(robot.type == RobotType.GARDENER) {
				gardener = robot;
				break;
			}
		}
		RobotInfo[] enemBots = rc.senseNearbyRobots(-1, rc.getTeam());
		if(enemBots.length > 0) {
			if(rc.canStrike()) {
				try {
					rc.strike();
					Clock.yield();
				} catch (GameActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		moveTowards(gardener.getLocation());
		Clock.yield();
	}
	public void moveTowards(MapLocation loc1) throws GameActionException{
		int r_l = 15;
		if(Math.random() > .5){
			 r_l = 45;
		} else{
			 r_l = -45;
		}
		Direction targetDir = rc.getLocation().directionTo(loc1);
		for(int i = 0; i < 8; i++){
			if(rc.canMove(targetDir)){
				rc.move(targetDir);
				rc.setIndicatorLine(rc.getLocation(), loc1, 0, 0, 1000);
			}else{
				targetDir = targetDir.rotateLeftDegrees(r_l);
			}
		}
	}
	void strikeBot(RobotInfo bot) {
		RobotInfo[] ourBots = rc.senseNearbyRobots(2, rc.getTeam());
		if(ourBots.length < 2) {
			if(rc.canStrike()) {
				try {
					rc.strike();
					Clock.yield();
				} catch (GameActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	void moveToBot(RobotInfo tree) throws GameActionException {
		Direction dirToMove = rc.getLocation().directionTo(tree.location);
		if(rc.canMove(dirToMove)) {
			try {
				rc.move(dirToMove);
				Clock.yield();
			} catch (GameActionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			if(rc.readBroadcast(12) != 10000){
                if(rc.canMove(new MapLocation((float)rc.readBroadcast(9), (float)rc.readBroadcast(10)))){
                	rc.move(new MapLocation((float)rc.readBroadcast(9), (float)rc.readBroadcast(10)));
                }else{
                	if(rc.canMove(new Direction(0))){
                		rc.move(new Direction(0));
                	} else{
                		if(rc.canMove(new Direction((float)Math.PI))){
                			rc.move(new Direction((float)Math.PI));
                		}
                	}
                }
            }else{
            	Direction ranDir = new Direction(BaseRobot.randomWithRange(0, (int)Math.PI * 2));
            	if(rc.canMove(ranDir)){
            		rc.move(ranDir);
            	}
            	else{
            		if(rc.canMove(new Direction(0))){
            			rc.move(new Direction(0));
            		}
            		
            	}
            }
			Clock.yield();
		}
	}
	void chopTree(TreeInfo tree) {
		if(rc.canChop(tree.ID)) {
			try {
				rc.chop(tree.ID);
				Clock.yield();
			} catch (GameActionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(rc.canShake(tree.ID)) {
			try {
				rc.shake(tree.ID);
				Clock.yield();
			} catch (GameActionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	void moveToTree(TreeInfo tree) throws GameActionException {
			Direction dirToMove = rc.getLocation().directionTo(tree.location);
			if(rc.canMove(dirToMove)) {
				try {
					rc.move(dirToMove);
					Clock.yield();
				} catch (GameActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				if(rc.readBroadcast(12) != 10000){
	                if(rc.canMove(new MapLocation((float)rc.readBroadcast(9), (float)rc.readBroadcast(10)))){
	                	rc.move(new MapLocation((float)rc.readBroadcast(9), (float)rc.readBroadcast(10)));
	                }else{
	                	if(rc.canMove(new Direction(0))){
	                		rc.move(new Direction(0));
	                	} else{
	                		if(rc.canMove(new Direction((float)Math.PI))){
	                			rc.move(new Direction((float)Math.PI));
	                		}
	                	}
	                }
                }else{
                	Direction ranDir = new Direction(BaseRobot.randomWithRange(0, (int)Math.PI * 2));
                	if(rc.canMove(ranDir)){
                		rc.move(ranDir);
                	}
                	else{
                		if(rc.canMove(new Direction(0))){
                			rc.move(new Direction(0));
                		}
                		
                	}
                }
				Clock.yield();
			}
	}
}
