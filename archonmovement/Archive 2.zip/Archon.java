package archonmovement;

import battlecode.common.*;

public class Archon extends BaseRobot {
	int gardenersMade = 0;
	int broadcastNum = 0;
	boolean canSpawn = false;
	static float arcDirection = 4.0f;
	Direction teamDir;
	float lastHealth = 40000;
	int curRound = 0;
	public Archon(RobotController rc) {
		super(rc);
	}
	void init() {
		System.out.println(rc.getInitialArchonLocations(rc.getTeam())[0].x);
		if(rc.getLocation().x == rc.getInitialArchonLocations(rc.getTeam())[0].x) {
			canSpawn = true;
		}
		if(rc.getTeam() == Team.A) {
			teamDir = new Direction((float) Math.PI);
		} else {
			teamDir = new Direction(0);
		}
	}
	void run() throws GameActionException {
		curRound = rc.getRoundNum();
		MapLocation myLoc = rc.getLocation();
		try {
			float hp = rc.getHealth();
			if(lastHealth < hp) {
				rc.broadcast(22, 1);
				rc.broadcast(23, (int) myLoc.x);
				rc.broadcast(24, (int) myLoc.y);
				goToCorner();
			}
			lastHealth = hp;
		} catch (GameActionException e) {

		}
		if (gardenersMade < 8) {
			arcMove();
			tryGardener();	
		} else {
			goToCorner();
		}
		Clock.yield();
	}
	void goToCorner() {
		Direction down = new Direction((float) Math.PI/2);
		if(rc.canMove(down)) {
			try {
				rc.move(down);
			} catch (GameActionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if(rc.canMove(teamDir)) {
			try {
				rc.move(teamDir);
			} catch (GameActionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	void tryGardener() {
		try {
			if(curRound % 30 == 0 || curRound < 10) {
				System.out.println("current round: " + curRound);
				for(int i = 0; i < dirList.length; i++) {
					//if(rc.readBroadcast(15) > 0){
					if(curRound < 10) {
						if(canSpawn && rc.canHireGardener(dirList[0])) {
							rc.hireGardener(dirList[0]);
							gardenersMade++;
							canSpawn = false;
							Clock.yield();
							//}
						}
					} else {
						if(rc.canHireGardener(dirList[0])) {
							rc.hireGardener(dirList[0]);
							gardenersMade++;
							Clock.yield();
							//}
						}
					}
				}
			}
		} catch (GameActionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void arcMove() {
		try {	
			BulletInfo[] bullets = rc.senseNearbyBullets();
			if(bullets.length>0){
				Direction newDir = rc.getLocation().directionTo(bullets[0].location).rotateLeftDegrees(90);
				Direction newDir2 = rc.getLocation().directionTo(bullets[0].location).rotateLeftDegrees(90);
				Direction newDir3 = rc.getLocation().directionTo(bullets[0].location).rotateRightDegrees(90);
				if(rc.canMove(newDir)){
					rc.move(newDir);
					Clock.yield();
				}
				else if(rc.canMove(newDir2)){
					rc.move(newDir2);
					Clock.yield();
				}
				else if(rc.canMove(newDir3)){
					rc.move(newDir3);
					Clock.yield();
				}
			}
			Direction dir;
			dir = new Direction(arcDirection);
			if(rc.canMove(dir)) {
				rc.move(dir);
			} else {
				arcDirection = (float) (arcDirection + Math.PI/((Math.random()* 2 + 4)));
			}
		} catch (GameActionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}